# precovid
Proyecto comunitario que tenía como fin ayudar en la trazabilidad de casos de personas contagiadas con COVID-19.
